
typedef struct {
  const char *z;
  int value;
  unsigned n;
} Token;
