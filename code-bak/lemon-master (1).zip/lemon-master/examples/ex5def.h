
typedef struct {
  const char *z;
  double value;
  unsigned n;
} Token;
